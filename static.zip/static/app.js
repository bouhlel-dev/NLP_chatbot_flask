class Chatbox {
    constructor() {
        this.args={
            openButton: document.querySelector('.chatbox__button'),
            chatBox: document.querySelector('.chatbox__support'),
            sendButton: document.querySelector('.send__button')
        }

        this.state =false;
        this.messages = [];

    }
    display() {
        const {openButton, chatBox, sendButton} = this.args;

        openButton.addEventListener('click', () => this.toggleState(chatBox))

        sendButton.addEventListener('click', () => this.onSendButton(chatBox))

        const node = chatBox.querySelector('input');
        node.addEventListener('keyup',({key}) => {
            if (key === "Enter"){
                this.onSendButton(chatBox)
            }
        })

        }


    toggleState(chatbox){
        this.state = !this.state ;

        if(this.state){
            chatbox.classlist.add('chatbox--active')
        } else {
            chatbox.classlist.remove('chatbox--active')
        }
    }
    

    onSendButton(chatbox){
        const valeur = document.getElementById("chat_input");
        const val = valeur.value;
        console.log(val);
        if(val === ""){
            return;
        }
        
        let msg1={name: "User", message: val}
        this.messages.push(msg1);
        console.log(msg1)

        //http://127.0.0.1:5000/predict
        fetch($SCRIPT_ROOT + '/predict' , {
            method: 'POST',
            body:JSON.stringify({message:val}),
            headers: {
                'Content-Type': 'application/json'
            },

        })
        .then(r => r.json())
        .then(r => {
            let msg2 = {name: "AHMED MOHSEN", message: r.answer};
            this.messages.push(msg2);
            this.updateChatText(chatbox)
            valeur.value =''


        }).catch((error) => {
            console.error('Error:',error);
            this.updateChatText(chatbox)
            textField.value= ''
        });
    }
    updateChatText(chatbox) {
        const html = this.messages.slice().reverse().map(item => {
            const className = (item.name === "AHMED MOHSEN") ? 'messages__item--visitor' : 'messages__item--operator';
            return `<div class="messages__item ${className}">${item.message}</div>`;
        }).join('');
    
        const chatmessage = chatbox.querySelector('.chatbox__messages');
        chatmessage.innerHTML = html;
    }


}

const chatbox =new Chatbox();
chatbox.display(); 


